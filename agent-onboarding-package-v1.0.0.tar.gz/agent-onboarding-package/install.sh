#!/usr/bin/env bash
#
# AI Agent Onboarding Package - Installation Script
#
# Usage:
#   ./install.sh [--project-root /path/to/project]
#
# This script installs the agent onboarding materials into your project.

set -euo pipefail

# Configuration
PACKAGE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="${1:-$(pwd)}"
AGENT_DIR="$PROJECT_ROOT/.agent"

echo "╔══════════════════════════════════════════════════════════════╗"
echo "║                                                              ║"
echo "║      AI Agent Onboarding Package Installation                ║"
echo "║                                                              ║"
echo "╚══════════════════════════════════════════════════════════════╝"
echo ""

# Step 1: Create directory structure
echo "📁 Creating directory structure..."
mkdir -p "$AGENT_DIR"/{docs,examples,templates}
echo "   ✓ Created $AGENT_DIR"

# Step 2: Copy core files
echo ""
echo "📋 Copying core files..."
cp "$PACKAGE_DIR/AGENTS.md" "$AGENT_DIR/"
echo "   ✓ AGENTS.md"

cp "$PACKAGE_DIR/README.md" "$AGENT_DIR/"
echo "   ✓ README.md"

# Step 3: Copy documentation
echo ""
echo "📚 Copying documentation..."
cp "$PACKAGE_DIR/docs/AVAILABLE_TOOLS.md" "$AGENT_DIR/docs/"
echo "   ✓ docs/AVAILABLE_TOOLS.md"

cp "$PACKAGE_DIR/docs/MCP_SERVERS.md" "$AGENT_DIR/docs/"
echo "   ✓ docs/MCP_SERVERS.md"

# Step 4: Copy examples
echo ""
echo "💡 Copying examples..."
cp "$PACKAGE_DIR/examples/CODE_EXAMPLES.md" "$AGENT_DIR/examples/"
echo "   ✓ examples/CODE_EXAMPLES.md"

# Step 5: Optional symlinks
echo ""
echo "🔗 Creating symlinks..."
if [ ! -e "$PROJECT_ROOT/AGENTS.md" ]; then
    ln -s ".agent/AGENTS.md" "$PROJECT_ROOT/AGENTS.md"
    echo "   ✓ Created AGENTS.md symlink in project root"
else
    echo "   ⚠ AGENTS.md already exists in project root (skipping symlink)"
fi

# Step 6: Create docs directory structure if needed
echo ""
echo "📂 Checking project documentation structure..."
mkdir -p "$PROJECT_ROOT/docs"/{archive,development}
echo "   ✓ docs/archive/ (for historical reports)"
echo "   ✓ docs/development/ (for technical decisions)"

# Step 7: Summary
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "✅ Installation complete!"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📍 Files installed to: $AGENT_DIR"
echo ""
echo "📝 Next steps:"
echo ""
echo "1. Customize for your project:"
echo "   vim $AGENT_DIR/AGENTS.md"
echo "   # Update sections 10-12 with project-specific info"
echo ""
echo "2. Add your tools:"
echo "   vim $AGENT_DIR/docs/AVAILABLE_TOOLS.md"
echo "   # Add custom scripts, MCP servers, etc."
echo ""
echo "3. Review with your team:"
echo "   cat $AGENT_DIR/README.md"
echo ""
echo "4. Start using:"
echo "   # AI agents should read AGENTS.md first"
echo "   # Reference: $PROJECT_ROOT/AGENTS.md"
echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo ""
echo "📖 Quick start: cat $PROJECT_ROOT/AGENTS.md"
echo ""
